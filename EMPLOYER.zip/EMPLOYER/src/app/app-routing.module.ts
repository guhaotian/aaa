import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { EmployeeComponent } from './components/employee/employee.component';
import { RecruitmentComponent } from './components/recruitment/recruitment.component';
import { EnterpriseComponent } from './components/enterprise/enterprise.component';
import { RelationshipComponent } from './components/relationship/relationship.component';
import { EventsComponent } from './components/events/events.component';
import { PlanComponent } from './components/plan/plan.component';
import { QuestionnaireComponent } from './components/questionnaire/questionnaire.component';
import { AnalysisComponent } from './components/analysis/analysis.component';
import { MeetingComponent } from './components/meeting/meeting.component';
import { ObservationComponent } from './components/observation/observation.component';
import { JobListComponent } from './components/job-list/job-list.component';
const routes: Routes = [
  {
    path:'home',
    component:HomeComponent
  },
  {
    path:'employee',
    component:EmployeeComponent
  },
  {
    path:'enterprise',
    component:EnterpriseComponent
  },
  {
    path:'Recruit',
    component:RecruitmentComponent
  },
  {
    path:'meeting',
    component:MeetingComponent
  },
  {
    path:'data',
    component:AnalysisComponent
  },
  {
    path:'quest',
    component:QuestionnaireComponent
  },
  {
    path:'plan',
    component:PlanComponent
  },
  {
    path:'event',
    component:EventsComponent
  },
  {
    path:'relate',
    component:RelationshipComponent
  },
  {
    path:'obs',
    component:ObservationComponent
  },
  {
    path:'jList',
    component:JobListComponent
  },

  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
