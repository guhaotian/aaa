import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.css']
})
export class CheckboxComponent implements OnInit {

  private departs = [
    {'name':'三','s':false},
    {'name':'四','s':false},
    {'name':'五','s':false}
  ]
  constructor() { }

  ngOnInit() {
  }

}
