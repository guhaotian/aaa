import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { EmployeeComponent } from './components/employee/employee.component';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { CheckboxComponent } from './checkbox/checkbox.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RecruitmentComponent } from './components/recruitment/recruitment.component';
import { EnterpriseComponent } from './components/enterprise/enterprise.component';
import { RelationshipComponent } from './components/relationship/relationship.component';

import { EventsComponent } from './components/events/events.component';
import { PlanComponent } from './components/plan/plan.component';
import { QuestionnaireComponent } from './components/questionnaire/questionnaire.component';
import { AnalysisComponent } from './components/analysis/analysis.component';
import { MeetingComponent } from './components/meeting/meeting.component';
import { ObservationComponent } from './components/observation/observation.component';
import { JobListComponent } from './components/job-list/job-list.component';
import { HttpModule, JsonpModule } from '@angular/http';
import { EmployeeSettingComponent } from './components/employee-setting/employee-setting.component';
import { EmployeeSettingRemindComponent } from './components/employee-setting-remind/employee-setting-remind.component';
import { EmployeeSettingCalendarComponent } from './components/employee-setting-calendar/employee-setting-calendar.component'; 
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    EmployeeComponent,
    HeaderComponent,
    SidebarComponent,
    CheckboxComponent,
    RecruitmentComponent,
    EnterpriseComponent,
    RelationshipComponent,
    EventsComponent,
    PlanComponent,
    QuestionnaireComponent,
    AnalysisComponent,
    MeetingComponent,
    ObservationComponent,
    JobListComponent,
    EmployeeSettingComponent,
    EmployeeSettingRemindComponent,
    EmployeeSettingCalendarComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    JsonpModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
