import { Component, OnInit } from '@angular/core';
import {Http,Jsonp} from "@angular/http";
@Component({
  selector: 'app-job-list',
  templateUrl: './job-list.component.html',
  styleUrls: ['./job-list.component.css']
})
export class JobListComponent implements OnInit {
  public list:any[];

  constructor(private http:Http,private jsonp:Jsonp) { 

  }

  ngOnInit() {
    var _that= this;
   var url="http://34.221.47.17:8000/business/employer/jobs/";
   this.http.get(url).subscribe(function(data){
      //console.log(JSON.parse(data['_body']));
      _that.list=JSON.parse(data['_body']);
      //console.log(_that.list)
   },
   function(err){
      console.log(err);
   }

   )
  }
 
  
}
 