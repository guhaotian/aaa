import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeSettingCalendarComponent } from './employee-setting-calendar.component';

describe('EmployeeSettingCalendarComponent', () => {
  let component: EmployeeSettingCalendarComponent;
  let fixture: ComponentFixture<EmployeeSettingCalendarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeSettingCalendarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeSettingCalendarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
