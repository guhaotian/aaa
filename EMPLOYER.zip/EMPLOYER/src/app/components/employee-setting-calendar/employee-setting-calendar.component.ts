import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-setting-calendar',
  templateUrl: './employee-setting-calendar.component.html',
  styleUrls: ['./employee-setting-calendar.component.css']
})
export class EmployeeSettingCalendarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
