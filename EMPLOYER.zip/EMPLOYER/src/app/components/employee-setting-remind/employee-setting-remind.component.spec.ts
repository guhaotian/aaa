import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeSettingRemindComponent } from './employee-setting-remind.component';

describe('EmployeeSettingRemindComponent', () => {
  let component: EmployeeSettingRemindComponent;
  let fixture: ComponentFixture<EmployeeSettingRemindComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeSettingRemindComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeSettingRemindComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
