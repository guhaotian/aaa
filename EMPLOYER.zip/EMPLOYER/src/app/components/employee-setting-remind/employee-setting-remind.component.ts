import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-setting-remind',
  templateUrl: './employee-setting-remind.component.html',
  styleUrls: ['./employee-setting-remind.component.css']
})
export class EmployeeSettingRemindComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
