import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-setting',
  templateUrl: './employee-setting.component.html',
  styleUrls: ['./employee-setting.component.css']
})
export class EmployeeSettingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
